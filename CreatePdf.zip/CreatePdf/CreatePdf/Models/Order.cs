﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CreatePdf.Models
{
    public class Order
    {
        [Key]
        public int PickListId { get; set; }
        public string OrderType { get; set; }
        public int WebOrderRef { get; set; }
        public string ProductId { get; set; }
        public string ProductName { get; set; }
        public int Quantity { get; set; }

    }
}
