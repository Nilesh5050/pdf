﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CreatePdf.Models;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using static iTextSharp.text.Font;
using iTextSharp.text.pdf.draw;

namespace CreatePdf.Controllers
{
    public class OrderController : Controller
    {
        private readonly ApplicationDbContext _context;

        public OrderController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Order
        public async Task<IActionResult> Index()
        {
            return View(await _context.Orders.ToListAsync());
        }

        public IActionResult Pdf()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Pdf(Order order)
        {
            using (MemoryStream ms=new MemoryStream())
            {
                var pgSize = new iTextSharp.text.Rectangle(400, 550);
                Document document = new Document(pgSize, 25, 25, 30, 30);
                PdfWriter writer = PdfWriter.GetInstance(document, ms);
                document.Open();

                var image = iTextSharp.text.Image.GetInstance("wwwroot/image/dummy profile.png");
                image.ScaleAbsolute(50f, 50f); // Set image size.
                image.Alignment = Element.ALIGN_LEFT;
                document.Add(image);



                Paragraph para1 = new Paragraph();
                Chunk glue1 = new Chunk(new VerticalPositionMark());
                Phrase ph1 = new Phrase();
                Paragraph main1 = new Paragraph();
                ph1.Add(new Chunk("PickList Id:                  "+"785476", new Font(FontFamily.HELVETICA, 10)));
                //ph1.Add(new Chunk("PickList Id:                  " + order.ProductId, new Font(FontFamily.HELVETICA, 10)));
                ph1.Add(glue1);
                main1.Add(ph1);
                para1.Add(main1);
                document.Add(para1);



                Paragraph para2 = new Paragraph();
                Chunk glue2 = new Chunk(new VerticalPositionMark());
                Phrase ph2 = new Phrase();
                Paragraph main2 = new Paragraph();
                ph2.Add(new Chunk("Order Type:                " + "Web order", new Font(FontFamily.HELVETICA, 10)));
                //ph2.Add(new Chunk("Order Type:                " + order.OrderType, new Font(FontFamily.HELVETICA, 10)));
                ph2.Add(glue2);
                main2.Add(ph2);
                para2.Add(main2);
                document.Add(para2);


                Paragraph para3 = new Paragraph();
                Chunk glue3 = new Chunk(new VerticalPositionMark());
                Phrase ph3 = new Phrase();
                Paragraph main3 = new Paragraph();
                ph3.Add(new Chunk("Web Order Ref:          " + "89567884", new Font(FontFamily.HELVETICA, 10)));
                //ph3.Add(new Chunk("Web Order Ref:          " + order.WebOrderRef, new Font(FontFamily.HELVETICA, 10)));
                ph3.Add(glue3);
                main3.Add(ph3);
                para3.Add(main3);
                para3.SpacingAfter = 50;
                document.Add(para3);




                Paragraph para4 = new Paragraph();
                Chunk glue4 = new Chunk(new VerticalPositionMark());
                Phrase ph4 = new Phrase();
                Phrase ph5 = new Phrase();
                Phrase ph6 = new Phrase();
                Paragraph main4 = new Paragraph();
                ph4.Add(new Chunk("Varenr:", new Font(FontFamily.HELVETICA, 10)));
                ph5.Add(new Chunk("      Varenavn:", new Font(FontFamily.HELVETICA, 10)));
                ph6.Add(new Chunk("Antal:", new Font(FontFamily.HELVETICA, 10)));
                //ph3.Add(new Chunk("Web Order Ref:          " + order.WebOrderRef, new Font(FontFamily.HELVETICA, 10)));
                ph4.Add(glue4);
                ph5.Add(glue4);
                ph6.Add(glue4);
                main4.Add(ph4);
                main4.Add(ph5);
                main4.Add(ph6);
                para4.Add(main4);
                
                para4.SpacingAfter = 10;
                document.Add(para4);

                LineSeparator line = new LineSeparator(1f, 100f, BaseColor.BLUE, Element.ALIGN_CENTER, 1);
                
                document.Add(line);


                Paragraph para5 = new Paragraph();
                Chunk glue5 = new Chunk(new VerticalPositionMark());
                Phrase ph7 = new Phrase();
                Phrase ph8 = new Phrase();
                Phrase ph9 = new Phrase();
                Paragraph main5 = new Paragraph();
                ph7.Add(new Chunk(order.ProductId, new Font(FontFamily.HELVETICA, 10)));
                ph8.Add(new Chunk(order.ProductName, new Font(FontFamily.HELVETICA, 10)));
                ph9.Add(new Chunk(order.Quantity.ToString(), new Font(FontFamily.HELVETICA, 10)));
                //ph3.Add(new Chunk("Web Order Ref:          " + order.WebOrderRef, new Font(FontFamily.HELVETICA, 10)));
                ph7.Add(glue5);
                ph8.Add(glue5);
                ph9.Add(glue5);
                main5.Add(ph7);
                main5.Add(ph8);
                main5.Add(ph9);
                para5.Add(main5);
                document.Add(para5);









                //Paragraph paral1 = new Paragraph("PicListId", new Font(FontFamily.HELVETICA, 20));
                //paral1.Alignment = Element.ALIGN_LEFT;
                //document.Add(paral1);

                //Paragraph paral11 = new Paragraph(order.PickListId.ToString(), new Font(FontFamily.HELVETICA, 20));
                //paral11.Alignment = Element.ALIGN_CENTER;
                //document.Add(paral11);

                //Paragraph paral2 = new Paragraph("Order Type", new Font(FontFamily.HELVETICA, 15));
                //paral2.Alignment = Element.ALIGN_LEFT;
                //document.Add(paral2);
                //Paragraph paral22 = new Paragraph(order.OrderType, new Font(FontFamily.HELVETICA, 15));
                //paral22.Alignment = Element.ALIGN_CENTER;
                //document.Add(paral22);

                //Paragraph paral3 = new Paragraph("Web Order ref", new Font(FontFamily.HELVETICA, 10));
                //paral3.Alignment = Element.ALIGN_LEFT;
                //document.Add(paral3);

                //Paragraph paral33 = new Paragraph(order.WebOrderRef.ToString(), new Font(FontFamily.HELVETICA, 10));
                //paral33.Alignment = Element.ALIGN_CENTER;
                //document.Add(paral33);





                //Paragraph pro1 = new Paragraph("Varener", new Font(FontFamily.HELVETICA, 10));
                //pro1.Alignment = Element.ALIGN_LEFT;
                //document.Add(pro1);
                //Paragraph pro2 = new Paragraph("Varenavn", new Font(FontFamily.HELVETICA, 10));
                //pro2.Alignment = Element.ALIGN_CENTER;
                //document.Add(pro2);
                //Paragraph pro3 = new Paragraph("Antal", new Font(FontFamily.HELVETICA, 10));
                //pro3.Alignment = Element.ALIGN_RIGHT;
                //document.Add(pro3);

                //LineSeparator line = new LineSeparator(1f, 100f, BaseColor.BLUE, Element.ALIGN_CENTER, 1);

                //document.Add(line);

                //Paragraph pro11 = new Paragraph(order.ProductId, new Font(FontFamily.HELVETICA, 10));
                //pro11.Alignment = Element.ALIGN_LEFT;
                //document.Add(pro11);

                //Paragraph pro22 = new Paragraph(order.ProductName, new Font(FontFamily.HELVETICA, 10));
                //pro22.Alignment = Element.ALIGN_CENTER;
                //document.Add(pro22);

                //Paragraph pro33 = new Paragraph(order.Quantity.ToString(), new Font(FontFamily.HELVETICA, 10));
                //pro33.Alignment = Element.ALIGN_RIGHT;
                //document.Add(pro33);



                //PdfPTable table = new PdfPTable(4);

                //PdfPCell cell1 = new PdfPCell(new Phrase("Date", new Font(Font.FontFamily.HELVETICA, 10)));
                //cell1.BackgroundColor = BaseColor.LIGHT_GRAY;
                //cell1.Border = Rectangle.BOTTOM_BORDER | Rectangle.TOP_BORDER | Rectangle.RIGHT_BORDER;
                //cell1.BorderWidthBottom = 1f;
                //cell1.BorderWidthTop = 1f;
                //cell1.BorderWidthLeft = 1f;
                //cell1.HorizontalAlignment = Element.ALIGN_CENTER;
                //cell1.VerticalAlignment = Element.ALIGN_CENTER;
                //table.AddCell(cell1);

                //PdfPCell cell2 = new PdfPCell(new Phrase("Name", new Font(Font.FontFamily.HELVETICA, 10)));
                //cell2.BackgroundColor = BaseColor.LIGHT_GRAY;
                //cell2.Border = Rectangle.BOTTOM_BORDER | Rectangle.TOP_BORDER | Rectangle.RIGHT_BORDER;
                //cell2.BorderWidthBottom = 1f;
                //cell2.BorderWidthTop = 1f;
                //cell2.BorderWidthLeft = 1f;
                //cell2.HorizontalAlignment = Element.ALIGN_CENTER;
                //cell2.VerticalAlignment = Element.ALIGN_CENTER;
                //table.AddCell(cell2);

                //PdfPCell cell3 = new PdfPCell(new Phrase("Surname", new Font(Font.FontFamily.HELVETICA, 10)));
                //cell3.BackgroundColor = BaseColor.LIGHT_GRAY;
                //cell3.Border = Rectangle.BOTTOM_BORDER | Rectangle.TOP_BORDER | Rectangle.RIGHT_BORDER;
                //cell3.BorderWidthBottom = 1f;
                //cell3.BorderWidthTop = 1f;
                //cell3.BorderWidthLeft = 1f;
                //cell3.VerticalAlignment = Element.ALIGN_CENTER;
                //cell3.HorizontalAlignment = Element.ALIGN_CENTER;
                //table.AddCell(cell3);


                //PdfPCell cell4 = new PdfPCell(new Phrase("Address", new Font(Font.FontFamily.HELVETICA, 10)));
                //cell4.BackgroundColor = BaseColor.LIGHT_GRAY;
                //cell4.Border = Rectangle.BOTTOM_BORDER | Rectangle.TOP_BORDER | Rectangle.RIGHT_BORDER;
                //cell4.BorderWidthBottom = 1f;
                //cell4.BorderWidthTop = 1f;
                //cell4.BorderWidthLeft = 1f;
                //cell4.HorizontalAlignment = Element.ALIGN_CENTER;
                //cell4.VerticalAlignment = Element.ALIGN_CENTER;
                //table.AddCell(cell4);

                //for (int i = 0; i < 100; i++)
                //{
                //    PdfPCell cell_1 = new PdfPCell(new Phrase(i.ToString()));
                //    PdfPCell cell_2 = new PdfPCell(new Phrase((i+1).ToString()));
                //    PdfPCell cell_3 = new PdfPCell(new Phrase((i + 2).ToString()));
                //    PdfPCell cell_4 = new PdfPCell(new Phrase((i + 3).ToString()));


                //    cell_1.HorizontalAlignment = Element.ALIGN_CENTER;
                //    cell_2.HorizontalAlignment = Element.ALIGN_CENTER;
                //    cell_3.HorizontalAlignment = Element.ALIGN_CENTER;
                //    cell_4.HorizontalAlignment = Element.ALIGN_CENTER;

                //    table.AddCell(cell_1);
                //    table.AddCell(cell_2);
                //    table.AddCell(cell_3);
                //    table.AddCell(cell_4);
                //}

                //document.Add(table);
                document.Close();
                writer.Close();
                var constant = ms.ToArray();
                return File(constant, "application/vnd", "Firstpdf.pdf");

            }
        }

        // GET: Order/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var order = await _context.Orders
                .FirstOrDefaultAsync(m => m.PickListId == id);
            if (order == null)
            {
                return NotFound();
            }

            return View(order);
        }

        // GET: Order/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Order/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PickListId,OrderType,WebOrderRef,ProductId,ProductName,Quantity")] Order order)
        {
            if (ModelState.IsValid)
            {
                _context.Add(order);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(order);
        }

        // GET: Order/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                return NotFound();
            }
            return View(order);
        }

        // POST: Order/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PickListId,OrderType,WebOrderRef,ProductId,ProductName,Quantity")] Order order)
        {
            if (id != order.PickListId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(order);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!OrderExists(order.PickListId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(order);
        }

        // GET: Order/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var order = await _context.Orders
                .FirstOrDefaultAsync(m => m.PickListId == id);
            if (order == null)
            {
                return NotFound();
            }

            return View(order);
        }

        // POST: Order/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var order = await _context.Orders.FindAsync(id);
            _context.Orders.Remove(order);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool OrderExists(int id)
        {
            return _context.Orders.Any(e => e.PickListId == id);
        }
    }
}
